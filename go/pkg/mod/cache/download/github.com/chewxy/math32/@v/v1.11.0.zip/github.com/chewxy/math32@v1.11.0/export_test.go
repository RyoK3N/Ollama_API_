package math32

// Export internal functions for testing.

// var Exp2Go = exp2
var SqrtGo = sqrt
var ExpGo = exp
var HypotGo = hypot
