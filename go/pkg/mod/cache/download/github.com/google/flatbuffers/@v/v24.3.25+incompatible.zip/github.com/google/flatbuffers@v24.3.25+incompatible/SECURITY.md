# Security Policy

## Reporting a Vulnerability

To report a security issue, please use http://g.co/vulnz. We use
http://g.co/vulnz for our intake, and do coordination and disclosure here on
GitHub (including using GitHub Security Advisory). The Google Security Team will
respond within 5 working days of your report on g.co/vulnz.

Select the `I want to report a technical security or an abuse risk related bug
in a Google product (SQLi, XSS, etc.)` option and complete the form.
