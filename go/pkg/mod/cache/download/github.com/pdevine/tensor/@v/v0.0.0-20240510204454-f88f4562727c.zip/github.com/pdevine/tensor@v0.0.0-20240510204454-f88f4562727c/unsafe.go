package tensor

import _ "go4.org/unsafe/assume-no-moving-gc"
