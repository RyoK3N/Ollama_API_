# go-bfloat16

BFloat16 conversion utilities for Go/Golang
